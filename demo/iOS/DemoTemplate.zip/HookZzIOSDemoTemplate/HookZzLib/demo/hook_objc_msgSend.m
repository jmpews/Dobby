#include "hookzz.h"
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <objc/message.h>
#import <objc/runtime.h>

#if defined(__LP64__)
typedef struct mach_header_64 mach_header_t;
typedef struct segment_command_64 segment_command_t;
typedef struct section_64 section_t;
typedef struct nlist_64 nlist_t;
#define LC_SEGMENT_ARCH_DEPENDENT LC_SEGMENT_64
#else
typedef struct mach_header mach_header_t;
typedef struct segment_command segment_command_t;
typedef struct section section_t;
typedef struct nlist nlist_t;
#define LC_SEGMENT_ARCH_DEPENDENT LC_SEGMENT
#endif

typedef void *zz_ptr_t;
typedef unsigned long zz_addr_t;

#if defined(__LP64__)
#define ZREG(n) general.regs.x##n
#else
#define ZREG(n) general.regs.r##n
#endif

char decollators[128]           = {0};
int filter_max                  = 0;
char *class_address_filters[20] = {0};

@interface HookZzDemo : NSObject

@end

@implementation HookZzDemo

+ (void)load {
    char *class_name_filters[20] = {
        "YYImage", "YYImageDecoder",
    };

    filter_max = sizeof(class_name_filters) / sizeof(char *);
    int i;
    for (i = 0; i < filter_max; i++) {
        class_address_filters[i] = objc_getClass(class_name_filters[i]);
    }

    [self hook_objc_msgSend];

    HookZzDemo *zz = [HookZzDemo new];
    [zz log_for_test];
}

- (void)log_for_test {
    NSLog(@"catch by HookZz");
}

+ (void)hook_objc_msgSend {
    DebugLogControlerEnableLog();
#if 0
    ZzHookGOT("objc_msgSend", NULL, NULL, objc_msgSend_pre_call, ojbc_msgSend_post_call);
#else
    ZzHook((void *)objc_msgSend, NULL, NULL, objc_msgSend_pre_call, ojbc_msgSend_post_call, false);
#endif
}

void objc_msgSend_pre_call(RegState *rs, ThreadStackPublic *threadstack, CallStackPublic *callstack) {
    char *sel_name = (char *)rs->ZREG(1);
    // No More Work Here!!! it will be slow.
    if (1) {
        // bad code! correct-ref: https://github.com/DavidGoldman/InspectiveC/blob/299cef1c40e8a165c697f97bcd317c5cfa55c4ba/logging.mm#L27
        void *object_addr = (void *)rs->ZREG(0);
        void *class_addr  = object_getClass((id)object_addr);
        if (!class_addr)
            return;

        int i;
        for (i = 0; class_address_filters[i] != 0; i++) {
            if ((zz_addr_t)class_address_filters[i] == (zz_addr_t)class_addr)
                break;
        }

        if (class_address_filters[i])
            return;

        memset(decollators, 45, 128);
        if (threadstack->size * 3 >= 128)
            return;
        decollators[threadstack->size * 3] = '\0';
        //            char *class_name = class_getName(object_addr);
        char *class_name               = object_getClassName(object_addr);
        unsigned int class_name_length = strlen(class_name);

#if 0
      // check View
      if(class_name_length >= 4 && !strcmp((class_name + class_name_length - 4), "View")) {
        printf(@"thread-id: %ld | %s [%s %s]", threadstack->thread_id, decollators, class_name, sel_name);
      }
#endif

#if 1
        printf("thread-id: %ld | %s [%s %s]\n", threadstack->thread_id, decollators, class_name, sel_name);
#endif

#if 0
      // check ViewController
      if(class_name_length >= 14 && !strcmp((class_name + class_name_length - 14), "ViewController")) {
        printf("thread-id: %ld | %s [%s %s]\n", threadstack->thread_id, decollators, class_name, sel_name);
      }
#endif
    }
}

void ojbc_msgSend_post_call(RegState *rs, ThreadStackPublic *threadstack, CallStackPublic *callstack) {
    NSLog(@"post call success.");
}

@end

zz_ptr_t MachoKitGetSectionByName(mach_header_t *header, char *sect_name) {
    struct load_command *load_cmd;
    segment_command_t *seg_cmd;
    section_t *sect;
    uintptr_t slide, linkEditBase;

    load_cmd = (struct load_command *)((zz_addr_t)header + sizeof(mach_header_t));
    for (uint i = 0; i < header->ncmds;
         i++, load_cmd = (struct load_command *)((zz_addr_t)load_cmd + load_cmd->cmdsize)) {
        if (load_cmd->cmd == LC_SEGMENT_ARCH_DEPENDENT) {
            seg_cmd = (segment_command_t *)load_cmd;
            if (seg_cmd->fileoff == 0 && seg_cmd->filesize != 0 && strcmp(seg_cmd->segname, "__TEXT") == 0) {
                slide = (uintptr_t)header - seg_cmd->vmaddr;
            }
            if (strcmp(seg_cmd->segname, "__LINKEDIT") == 0) {
                linkEditBase = seg_cmd->vmaddr - seg_cmd->fileoff + slide;
            }
            sect = (section_t *)((zz_addr_t)seg_cmd + sizeof(segment_command_t));
            for (uint j = 0; j < seg_cmd->nsects;
                 j++, sect = (section_t *)((zz_addr_t)sect + sizeof(section_t))) {
                if (!strcmp(sect->sectname, sect_name)) {
                    return (zz_ptr_t)(sect->addr + slide);
                }
            }
        }
    }
    return NULL;
}

segment_command_t *MachoKitGetSegmentByName(mach_header_t *header, char *segment_name) {
    struct load_command *load_cmd;
    segment_command_t *seg_cmd;

    load_cmd = (struct load_command *)((zz_addr_t)header + sizeof(mach_header_t));
    for (uint i = 0; i < header->ncmds;
         i++, load_cmd = (struct load_command *)((zz_addr_t)load_cmd + load_cmd->cmdsize)) {
        if (load_cmd->cmd == LC_SEGMENT_ARCH_DEPENDENT) {
            seg_cmd = (segment_command_t *)load_cmd;
            if (!strcmp(seg_cmd->segname, segment_name)) {
                return seg_cmd;
            }
        }
    }
    return NULL;
}
