//
//  AppDelegate.h
//  HookZzIOSDemoTemplate
//
//  Created by jmpews on 2018/2/27.
//  Copyright © 2018年 jmpews. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

