#include <stdlib.h>
#include <string.h>

#include "relocator-thumb.h"

#define MAX_RELOCATOR_INSTRUCIONS_SIZE 64

void zz_thumb_relocator_init(ZzThumbRelocator *relocator, ZzARMReader *input, ZzThumbAssemblerWriter *output) {
    memset(relocator, 0, sizeof(ZzThumbRelocator));
    relocator->inpos                       = 0;
    relocator->outpos                      = 0;
    relocator->input                       = input;
    relocator->output                      = output;
    relocator->try_relocated_length        = 0;
}

void zz_thumb_relocator_free(ZzThumbRelocator *relocator) {
    zz_thumb_reader_free(relocator->input);
    zz_thumb_writer_free(relocator->output);
    free(relocator);
}

void zz_thumb_relocator_reset(ZzThumbRelocator *self, ZzARMReader *input, ZzThumbAssemblerWriter *output) {
    self->inpos                       = 0;
    self->outpos                      = 0;
    self->input                       = input;
    self->output                      = output;
    self->literal_insn_size = 0;
    self->try_relocated_length        = 0;
}

void zz_thumb_relocator_read_one(ZzThumbRelocator *self, ZzARMInstruction *instruction) {
    ZzARMInstruction *insn_ctx;

    zz_thumb_reader_read_one_instruction(self->input);

    // switch (1) {}

    self->inpos++;

    if (instruction != NULL)
        *instruction = *insn_ctx;
}

void zz_thumb_relocator_try_relocate(zz_ptr_t address, zz_size_t min_bytes, zz_size_t *max_bytes) {
    int tmp_size = 0;
    bool is_thumb;
    zz_ptr_t target_addr;
    bool early_end = FALSE;
    is_thumb       = INSTRUCTION_IS_THUMB((zz_addr_t)address);

    ZzARMInstruction *insn_ctx;
    ZzARMReader *reader = zz_thumb_reader_new(address);

    do {
        insn_ctx = zz_thumb_reader_read_one_instruction(reader);
        switch (GetTHUMBInsnType(insn_ctx->insn1, insn_ctx->insn2)) {
        case THUMB_INS_B_T2:
            early_end = TRUE;
            break;
        case THUMB_INS_B_T4:
            early_end = TRUE;
            break;
        default:;
        }
        tmp_size += insn_ctx->size;
        target_addr = target_addr + insn_ctx->size;
    } while (tmp_size < min_bytes);

    if (early_end) {
        *max_bytes = tmp_size;
    }

    zz_thumb_reader_free(reader);
    return;
}

#if 0
zz_addr_t zz_thumb_relocator_get_insn_relocated_offset(ZzThumbRelocator *self, zz_addr_t address) {
    const ZzARMInstruction *insn_ctx;
    const ZzRelocateInstruction *re_insn_ctx;
    int i;

    for (i = 0; i < self->inpos; i++) {
        re_insn_ctx = &self->output_insns[i];
        insn_ctx    = re_insn_ctx->insn_ctx;
        if (insn_ctx->address == address && re_insn_ctx->relocated_offset) {
            return re_insn_ctx->relocated_offset;
        }
    }
    return 0;
}

#endif
void zz_thumb_relocator_relocate_writer(ZzThumbRelocator *relocator, zz_addr_t final_relocate_address) {
    ZzThumbAssemblerWriter *thumb_writer;
    thumb_writer = relocator->output;
    if (relocator->literal_insn_size) {
        zz_size_t literal_offset;
        zz_addr_t *literal_target_address_ptr;
        for (int i = 0; i < relocator->literal_insn_size; i++) {
            literal_target_address_ptr = (zz_addr_t *)relocator->literal_insns[i]->address;
            *literal_target_address_ptr += final_relocate_address;

        }
    }
}

void zz_thumb_relocator_write_all(ZzThumbRelocator *self) {
    int count                           = 0;
    int outpos                          = self->outpos;
    ZzThumbAssemblerWriter thumb_writer = *self->output;
    while (zz_thumb_relocator_write_one(self))
        count++;
}

void zz_thumb_relocator_register_literal_insn(ZzThumbRelocator *self, ZzARMInstruction *insn_ctx) {
    self->literal_insns[self->literal_insn_size++] = insn_ctx;
    // convert the temportary absolute address with offset.
    zz_addr_t *temp_address = insn_ctx->address;
    *temp_address = insn_ctx->pc - self->output->start_pc;   
}

// A8-357
// 0: cbz #0
// 2: b #6
// 4: ldr pc, #0
// 8: .long ?
// c: next insn
static bool zz_thumb_relocator_rewrite_CBNZ_CBZ(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {

    uint32_t insn1 = insn_ctx->insn1;
    uint16_t op, i, imm5, Rn_ndx;
    uint32_t imm32, nonzero;

    op     = get_insn_sub(insn1, 11, 1);
    i      = get_insn_sub(insn1, 9, 1);
    imm5   = get_insn_sub(insn1, 3, 5);
    Rn_ndx = get_insn_sub(insn1, 0, 3);

    imm32   = imm5 << 1 | i << (5 + 1);
    nonzero = (op == 1);

    zz_addr_t target_address = insn_ctx->pc + imm32;

    /* for align , simple solution, maybe the correct solution is get `ldr_reg_address` length and adjust the immediate
     * of `b_imm`. */
    if ((zz_addr_t)self->output->current_pc % 4) {
        zz_thumb_writer_put_nop(self->output);
    }
    zz_thumb_writer_put_instruction(self->output, (insn1 & 0b1111110100000111) | 0);
    zz_thumb_writer_put_b_imm(self->output, 0x6);
    zz_thumb_writer_put_ldr_reg_address(self->output, ZZ_ARM_REG_PC, target_address + 1);
    // register literal instruction
    if(target_address > self->input->start_pc && target_address < (self->input->start_pc+ self->input->size))
        zz_thumb_relocator_register_literal_insn(self, self->output->insns[self->output->insn_size - 1]);
    return TRUE;
}

// PAGE: A8-310
static bool zz_thumb_relocator_rewrite_ADD_register_T2(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;

    uint16_t Rm_ndx, Rdn_ndx, DN, Rd_ndx;
    Rm_ndx  = get_insn_sub(insn1, 3, 4);
    Rdn_ndx = get_insn_sub(insn1, 0, 3);
    DN      = get_insn_sub(insn1, 7, 1);
    Rd_ndx  = (DN << 3) | Rdn_ndx;

    if (Rm_ndx != ZZ_ARM_REG_PC) {
        return FALSE;
    }

    zz_thumb_writer_put_push_reg(self->output, ZZ_ARM_REG_R7);
    zz_thumb_writer_put_ldr_b_reg_address(self->output, ZZ_ARM_REG_R7, insn_ctx->pc);
    zz_thumb_writer_put_instruction(self->output, (insn1 & 0b1111111110000111) | ZZ_ARM_REG_R7 << 3);
    zz_thumb_writer_put_pop_reg(self->output, ZZ_ARM_REG_R7);

    return TRUE;
}

// PAGE: A8-410
bool zz_thumb_relocator_rewrite_LDR_literal_T1(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1           = insn_ctx->insn1;
    uint32_t imm8            = get_insn_sub(insn1, 0, 8);
    uint32_t imm32           = imm8 << 2;
    // TODO: must be align_4 ?
    zz_addr_t target_address = ALIGN_4(insn_ctx->pc) + imm32;
    int Rt_ndx               = get_insn_sub(insn1, 8, 3);

    zz_thumb_writer_put_ldr_b_reg_address(self->output, Rt_ndx, target_address);
    zz_thumb_writer_put_ldr_reg_reg_offset(self->output, Rt_ndx, Rt_ndx, 0);

    return TRUE;
}

// PAGE: A8-410
bool zz_thumb_relocator_rewrite_LDR_literal_T2(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;
    uint32_t insn2 = insn_ctx->insn2;

    uint32_t imm12 = get_insn_sub(insn2, 0, 12);
    uint32_t imm32 = imm12;

    bool add = get_insn_sub(insn_ctx->insn1, 7, 1) == 1;
    zz_addr_t target_address;
    if (add)
        target_address = ALIGN_4(insn_ctx->pc) + imm32;
    else
        target_address = ALIGN_4(insn_ctx->pc) - imm32;
    int Rt_ndx = get_insn_sub(insn_ctx->insn2, 12, 4);

    zz_thumb_writer_put_ldr_b_reg_address(self->output, Rt_ndx, target_address);
    zz_thumb_writer_put_ldr_reg_reg_offset(self->output, Rt_ndx, Rt_ndx, 0);

    return TRUE;
}

// PAGE: A8-322
bool zz_thumb_relocator_rewrite_ADR_T1(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;

    uint32_t imm8            = get_insn_sub(insn1, 0, 8);
    uint32_t imm32           = imm8 << 2;
    zz_addr_t target_address = insn_ctx->pc + imm32;
    int Rt_ndx               = get_insn_sub(insn1, 8, 3);

    zz_thumb_writer_put_ldr_b_reg_address(self->output, Rt_ndx, target_address);
    return TRUE;
}

// PAGE: A8-322
bool zz_thumb_relocator_rewrite_ADR_T2(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;
    uint32_t insn2 = insn_ctx->insn2;

    uint32_t imm32 =
        get_insn_sub(insn2, 0, 8) | (get_insn_sub(insn2, 12, 3) << 8) | ((get_insn_sub(insn1, 10, 1) << (3 + 8)));

    zz_addr_t target_address;
    target_address = insn_ctx->pc - imm32;
    int Rt_ndx     = get_insn_sub(insn_ctx->insn2, 8, 4);
    zz_thumb_writer_put_ldr_b_reg_address(self->output, Rt_ndx, target_address);
    return TRUE;
}

// PAGE: A8-322
bool zz_thumb_relocator_rewrite_ADR_T3(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;
    uint32_t insn2 = insn_ctx->insn2;

    uint32_t imm32 =
        get_insn_sub(insn2, 0, 8) | (get_insn_sub(insn2, 12, 3) << 8) | ((get_insn_sub(insn1, 10, 1) << (3 + 8)));

    zz_addr_t target_address;
    target_address = insn_ctx->pc + imm32;
    int Rt_ndx     = get_insn_sub(insn_ctx->insn2, 8, 4);

    zz_thumb_writer_put_ldr_b_reg_address(self->output, Rt_ndx, target_address);
    return TRUE;
}

// 0x000 : b.cond 0x0;
// 0x002 : b 0x6
// 0x004 : ldr pc, [pc, #0]
// 0x008 : .long 0x0
// 0x00c : remain code

// PAGE: A8-334
bool zz_thumb_relocator_rewrite_B_T1(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;
    // uint32_t insn2 = insn_ctx->insn2;

    uint32_t imm8            = get_insn_sub(insn1, 0, 8);
    uint32_t imm32           = imm8 << 1;
    zz_addr_t target_address = insn_ctx->pc + imm32;

    /* for align , simple solution, maybe the correct solution is get `ldr_reg_address` length and adjust the immediate
     * of `b_imm`. */
    if ((zz_addr_t)self->output->current_pc % 4) {
        zz_thumb_writer_put_nop(self->output);
    }
    zz_thumb_writer_put_instruction(self->output, (insn1 & 0xFF00) | 0);
    zz_thumb_writer_put_b_imm(self->output, 0x6);
    zz_thumb_writer_put_ldr_reg_address(self->output, ZZ_ARM_REG_PC, target_address + 1);
    return TRUE;
}

// PAGE: A8-334
bool zz_thumb_relocator_rewrite_B_T2(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;

    uint32_t imm11           = get_insn_sub(insn1, 0, 11);
    uint32_t imm32           = imm11 << 1;
    zz_addr_t target_address = insn_ctx->pc + imm32;

    zz_thumb_writer_put_ldr_reg_address(self->output, ZZ_ARM_REG_PC, target_address + 1);
    return TRUE;
}

// 0x002 : b.cond.W 0x2;
// 0x006 : b 0x6
// 0x008 : ldr pc, [pc, #0]
// 0x00c : .long 0x0
// 0x010 : remain code

// PAGE: A8-334
bool zz_thumb_relocator_rewrite_B_T3(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;
    uint32_t insn2 = insn_ctx->insn2;

    int S     = get_insn_sub(insn_ctx->insn1, 10, 1);
    int J2    = get_insn_sub(insn_ctx->insn2, 11, 1);
    int J1    = get_insn_sub(insn_ctx->insn2, 13, 1);
    int imm6  = get_insn_sub(insn_ctx->insn1, 0, 6);
    int imm11 = get_insn_sub(insn_ctx->insn2, 0, 11);
    uint32_t imm32 =
        imm11 << 1 | imm6 << (1 + 11) | J1 << (1 + 11 + 6) | J2 << (1 + 11 + 6 + 1) | S << (1 + 11 + 6 + 1 + 1);
    zz_addr_t target_address;
    target_address = insn_ctx->pc + imm32;

    /* for align , simple solution, maybe the correct solution is get `ldr_reg_address` length and adjust the immediate
     * of `b_imm`. */
    if ((zz_addr_t)self->output->current_pc % 4 == 0) {
        zz_thumb_writer_put_nop(self->output);
    }
    zz_thumb_writer_put_instruction(self->output, insn_ctx->insn1 & 0b1111101111000000);
    zz_thumb_writer_put_instruction(self->output, (insn_ctx->insn2 & 0b1101000000000000) | 0b1);
    zz_thumb_writer_put_b_imm(self->output, 0x6);
    zz_thumb_writer_put_ldr_reg_address(self->output, ZZ_ARM_REG_PC, target_address + 1);
    return TRUE;
}

// PAGE: A8-334
bool zz_thumb_relocator_rewrite_B_T4(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;
    uint32_t insn2 = insn_ctx->insn2;

    uint32_t S     = get_insn_sub(insn_ctx->insn1, 10 + 16, 1);
    uint32_t J2    = get_insn_sub(insn_ctx->insn2, 11, 1);
    uint32_t J1    = get_insn_sub(insn_ctx->insn2, 13, 1);
    uint32_t imm10 = get_insn_sub(insn_ctx->insn1, 0, 10);
    uint32_t imm11 = get_insn_sub(insn_ctx->insn2, 0, 11);
    uint32_t I1    = (~(J1 ^ S)) & 0x1;
    uint32_t I2    = (~(J2 ^ S)) & 0x1;
    uint32_t imm32 =
        imm11 << 1 | imm10 << (1 + 11) | I1 << (1 + 11 + 6) | I2 << (1 + 11 + 6 + 1) | S << (1 + 11 + 6 + 1 + 1);
    zz_addr_t target_address;
    target_address = insn_ctx->pc + imm32;

    zz_thumb_writer_put_ldr_reg_address(self->output, ZZ_ARM_REG_PC, target_address + 1);
    return TRUE;
}

// PAGE: A8-348
bool zz_thumb_relocator_rewrite_BLBLX_immediate_T1(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;
    uint32_t insn2 = insn_ctx->insn2;

    uint32_t S     = get_insn_sub(insn_ctx->insn1, 10, 1);
    uint32_t J2    = get_insn_sub(insn_ctx->insn2, 11, 1);
    uint32_t J1    = get_insn_sub(insn_ctx->insn2, 13, 1);
    uint32_t imm10 = get_insn_sub(insn_ctx->insn1, 0, 10);
    uint32_t imm11 = get_insn_sub(insn_ctx->insn2, 0, 11);
    uint32_t I1    = (~(J1 ^ S)) & 0x1;
    uint32_t I2    = (~(J2 ^ S)) & 0x1;
    uint32_t imm32 =
        imm11 << 1 | imm10 << (1 + 11) | I1 << (1 + 11 + 6) | I2 << (1 + 11 + 6 + 1) | S << (1 + 11 + 6 + 1 + 1);
    zz_addr_t target_address;

    // CurrentInstrSet = thumb
    // targetInstrSet = arm
    target_address = insn_ctx->pc + imm32;

    zz_thumb_writer_put_ldr_b_reg_address(self->output, ZZ_ARM_REG_LR, insn_ctx->pc + 1);
    // register literal instruction
    if(target_address > self->input->start_pc && target_address < (self->input->start_pc+ self->input->size))
        zz_thumb_relocator_register_literal_insn(self, self->output->insns[self->output->insn_size - 1]);
    zz_thumb_writer_put_ldr_reg_address(self->output, ZZ_ARM_REG_PC, target_address + 1);
    return TRUE;
}

// PAGE: A8-348
bool zz_thumb_relocator_rewrite_BLBLX_T2(ZzThumbRelocator *self, const ZzARMInstruction *insn_ctx) {
    uint32_t insn1 = insn_ctx->insn1;
    uint32_t insn2 = insn_ctx->insn2;

    uint32_t S       = get_insn_sub(insn_ctx->insn1, 10, 1);
    uint32_t J2      = get_insn_sub(insn_ctx->insn2, 11, 1);
    uint32_t J1      = get_insn_sub(insn_ctx->insn2, 13, 1);
    uint32_t imm10_1 = get_insn_sub(insn_ctx->insn1, 0, 10);
    uint32_t imm10_2 = get_insn_sub(insn_ctx->insn2, 1, 10);
    uint32_t I1      = (~(J1 ^ S)) & 0x1;
    uint32_t I2      = (~(J2 ^ S)) & 0x1;
    ;
    uint32_t H = get_insn_sub(insn_ctx->insn2, 0, 1);
    uint32_t imm32 =
        imm10_2 << 2 | imm10_1 << (2 + 10) | I1 << (2 + 10 + 6) | I2 << (2 + 10 + 6 + 1) | S << (2 + 10 + 6 + 1 + 1);
    zz_addr_t target_address;

    // CurrentInstrSet = thumb
    // targetInstrSet = arm
    target_address = ALIGN_4(insn_ctx->pc) + imm32;

    zz_thumb_writer_put_ldr_b_reg_address(self->output, ZZ_ARM_REG_LR, insn_ctx->pc + 1);
    // register literal instruction
    if(target_address > self->input->start_pc && target_address < (self->input->start_pc+ self->input->size))
        zz_thumb_relocator_register_literal_insn(self, self->output->insns[self->output->insn_size - 1]);
    zz_thumb_writer_put_ldr_reg_address(self->output, ZZ_ARM_REG_PC, target_address);
    return TRUE;
}

bool zz_thumb_relocator_write_one(ZzThumbRelocator *self) {
    ZzARMInstruction *insn_ctx, **input_insns;
    bool rewritten = FALSE;

    if (self->inpos != self->outpos) {
        input_insns = self->input->insns;
        insn_ctx    = input_insns[self->outpos];
        self->outpos++;
    } else
        return FALSE;

    switch (GetTHUMBInsnType(insn_ctx->insn1, insn_ctx->insn2)) {
    case THUMB_INS_CBNZ_CBZ:
        rewritten = zz_thumb_relocator_rewrite_CBNZ_CBZ(self, insn_ctx);
        break;
    case THUMB_INS_ADD_register_T2:
        rewritten = zz_thumb_relocator_rewrite_ADD_register_T2(self, insn_ctx);
        break;
    case THUMB_INS_LDR_literal_T1:
        rewritten = zz_thumb_relocator_rewrite_LDR_literal_T1(self, insn_ctx);
        break;
    case THUMB_INS_LDR_literal_T2:
        rewritten = zz_thumb_relocator_rewrite_LDR_literal_T2(self, insn_ctx);
        break;
    case THUMB_INS_ADR_T1:
        rewritten = zz_thumb_relocator_rewrite_ADR_T1(self, insn_ctx);
        break;
    case THUMB_INS_ADR_T2:
        rewritten = zz_thumb_relocator_rewrite_ADR_T2(self, insn_ctx);
        break;
    case THUMB_INS_ADR_T3:
        rewritten = zz_thumb_relocator_rewrite_ADR_T3(self, insn_ctx);
        break;
    case THUMB_INS_B_T1:
        rewritten = zz_thumb_relocator_rewrite_B_T1(self, insn_ctx);
        break;
    case THUMB_INS_B_T2:
        rewritten = zz_thumb_relocator_rewrite_B_T2(self, insn_ctx);
        break;
    case THUMB_INS_B_T3:
        rewritten = zz_thumb_relocator_rewrite_B_T3(self, insn_ctx);
        break;
    case THUMB_INS_B_T4:
        rewritten = zz_thumb_relocator_rewrite_B_T4(self, insn_ctx);
        break;
    case THUMB_INS_BLBLX_immediate_T1:
        rewritten = zz_thumb_relocator_rewrite_BLBLX_immediate_T1(self, insn_ctx);
        break;
    case THUMB_INS_BLBLX_immediate_T2:
        rewritten = zz_thumb_relocator_rewrite_BLBLX_T2(self, insn_ctx);
        break;
    case THUMB_UNDEF:
        rewritten = FALSE;
        break;
    }

    if (!rewritten) {
        zz_thumb_writer_put_bytes(self->output, (char *)&insn_ctx->insn, insn_ctx->size);
    } else {
    }

    return TRUE;
}
