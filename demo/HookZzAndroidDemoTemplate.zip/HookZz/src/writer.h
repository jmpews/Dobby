#ifndef writer_h
#define writer_h

#include "hookzz.h"
#include "kitzz.h"

#define MAX_LITERAL_INSN_SIZE 128


#endif
